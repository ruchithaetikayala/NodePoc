const mongoose = require('mongoose')

const productSchema = mongoose.Schema({
    title: {
        type: String,
        required: true
    },
    posted_user: {
        type: String,
        required: true
    },
    category: {
        type: String,
        required: true,
    },
    brand: {
        type: String,
        required: true,
    },
    description: {
        type: String,
        required: true,
    },
    rating: {
        type: Number,
        min: 0,
        max: 5
    },
    images:
    {
        type: [String],
        required: true,
    },
    location: {
        type: [String],
        required: true
    },
    costPerDay: {
        type: Number,
        required: true
    }


})


const Product = mongoose.model('Product', productSchema)

module.exports = Product