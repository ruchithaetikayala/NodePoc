const express = require('express')
const router = express.Router()
const productController = require('../controllers/productController')
const authController = require('../controllers/authController')

router.route('/').get(productController.getAllProducts).post(productController.createNewProduct)
router.route('/:id').get(productController.getAProduct).patch(authController.protect, productController.updateProduct).delete(authController.protect, productController.deleteProduct)

module.exports = router