const Product = require("../models/productModel");
const catchAsync = require('../utils/catchError')
const AppError = require("../utils/appError");

exports.getAllProducts = catchAsync(async (req, res, next) => {

    const products = await Product.find()

    if (!products) {
        return next(new AppError('Cannot find products', 404))

    }

    res.json({ status: 'success', data: products })

})
exports.getAProduct = catchAsync(async (req, res, next) => {


    const { id } = req.params
    const product = await Product.findById({ _id: id })

    if (!product) {
        return next(new AppError('Cannot find the product', 404))

    }
    res.json({ status: 'success', data: product })

})

exports.createNewProduct = catchAsync(async (req, res, next) => {
    const product = await Product.create(req.body)
    res.status(201).json({ status: 'success', data: product })

})
exports.updateProduct = catchAsync(async (req, res, next) => {

    const { id } = req.params

    const product = await Product.findByIdAndUpdate(id, req.body, { new: true })
    if (!product) {
        return next(new AppError('Cannot update the product', 404))
    }

    res.status(200).json({ status: 'success', data: product })
})
exports.deleteProduct = catchAsync(async (req, res, next) => {
    const { id } = req.params
    const product = await Product.findByIdAndDelete(id)

    if (!product) {
        return next(new AppError('Cannot delete the product', 404))
    }

    res.status(200).json({ status: 'success', data: product })

})
