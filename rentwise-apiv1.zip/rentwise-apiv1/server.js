const dotenv = require('dotenv')
dotenv.config({ path: './config.env' })

process.on('uncaughtException', err => {
    console.log('UNCAUGHT EXCEPTION! 💥 Shutting down...');
    console.log(err.name, err.message);
    process.exit(1);
});

const app = require('./app')
const { default: mongoose } = require('mongoose')
const PORT = 4000 || process.env.PORT


const URL = process.env.MONGODB_URL.replace('<password>', process.env.MONGODB_PASSWORD);


mongoose.connect(URL).then(() => {
    console.log('Server Connected with DB')
}).catch(err => console.log('Problem with DB connection', err))




const server = app.listen(PORT, () => {
    console.log(`Server running successfully on PORT ${PORT}`)
})



process.on('unhandledRejection', err => {
    console.log(err.name, err, message)
    console.log('UNHANDLED REJECTION! 💥 Shutting down...')
    server.close(() => {
        process.exit(1)
    })
})
